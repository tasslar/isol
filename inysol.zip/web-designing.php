<?php include 'header.php';?>
<div class="inner-banner"><img src="images/web-design.jpg" class="img-responsive"></div>

        
        <div class="services-full-width-container">
        	<div class="container">
	            <div class="row">
	                <div class="col-sm-12 services-full-width-text wow fadeInLeft">
	                    <h3 style="color:#EE2326; text-transform:uppercase;">Static Website Design Services</h3>
	                    <p>
	                    The static website is simple website design which is cost effective and beneficial for the small enterprises or individual to expand their business through web. Through static website individuals or smallbusiness houses can place simple information regarding their company and products in simple manner and at low cost. This type of website is very useful for expanding market of company with its information and appearance on Internet.

A static website is just you write your material in any word processor and upload it as an .html or .htm web page. Static websites are simple in character and can be link easily together. There are many websites that provide free static templates for creating static website. According to your company's need you can choose among templates and place your content accordingly.

The static website is the best and most simplest way of establishing your global corporate identity on World Wide Web. With the help of static templates you can make your sites online quickly. The only consideration you have to take is to have basic knowledge of hypertext markup language (HTML). The static templates use either tables or CSS (cascading style sheet) for positioning contents. The CSS style remains the preferred choice. CSS allow users to develop cleaner format with less code in the actual page itself.

A static website is perfect for individuals, businesses or companies that have a message that change slowly. In static website users can quickly and easily put contents and images without having much experience. The static website is ideal for demonstrating how your website will look on Internet. Cache friendly copy of website can be shown to many people.

Through Static websites you can showcase products, services and information in an effective way. It is most cost effective in online product advertising. A static website is quite suitable where updating the products or services is not required. Static web designs are ideal for downloading images, brochures etc. Static websites are browser friendly and easy to navigate.
	                	</p>
	                </div>
	            </div>
	        </div>
        </div>

        <!-- Services -->
     

        <!-- Services Half Width Text -->
        <div class="services-half-width-container">
        	<div class="container">
	            <div class="row">
	                <div class="col-sm-12 services-full-width-text wow fadeInLeft">
	                    <h3 style="color:#EE2326; text-transform:uppercase;">Search Engine Optimization</h3>
	                    <p>
	               With more & more people accessing the World Wide Web everyday instead of the yellow pages, even the small businesses cannot afford to ignore this important, growing media to expose themselves to potential customers. Many web designers charge premium prices for creating web pages thereby limiting many small businesses from maintaining apresence on the Internet.

Our aim is to get your business goals accomplished through your website which will definitely be attractive, easy to navigate, professional looking and fully customized according to your business specific domain.?
Inysol Innovative Solutions caters to small businesses, Large Organizations and individuals. We believe in straightforward,reliable web page creation at affordable prices – whether you are an individual,business, or organization, we can help create and customize a website according to your particular needs.

Professional and Creative Web DesigningLet us create a web site that will promote your business or your personal homepage in a professional and creative way. 

Since your business is unique from your competitors'business, why not have a web site that is unique from your competitors' web site?
Inysol Innovative Solutions does not use 'Template' and 'fill-in-the-blank' programs to design websites; we start each one from grass root level. 
	                    </p>
                       
	                </div>
	                <div class="col-sm-12 services-full-width-text wow fadeInUp ">
	                     <h3 style="color:#EE2326; text-transform:uppercase;">Website Design with a difference:</h3>
	                    <p>
	                  Web design is the process of planning and creating a website.Text, images, digital media and interactive elements are shaped by the web designer to bring forth the page seen on the web browser.
Web designers utilize markup language, most noteworthy HTML for structure and CSS for presentation to develop pages that can be read by web browsers.

web designersOur web designers are specialized in making quality web sites that can help you to achieve your company targets over web. Designing web site is only a part of a successful online presence over the internet. We use all the latest and most established technology to create a web site that is visually appealing and yet fully functional.All our works are designed in a manner to give people the most convenient & usable designs that are completely devised according to the web standards using CSS & search engine visibility.

We listen to you when you give is feedback and ideas, so that we create the web site you want - just not any web site.
	                    </p>
	                </div>
	            </div>
	        </div>
        </div>

        <!-- Call To Action -->
        <div class="call-to-action-container">
        	<div class="container">
	            <div class="row">
	                <div class="col-sm-12 call-to-action-text wow fadeInLeftBig">
	                    <p>
	                    	<span class="violet">In the online business, the dynamic website is cheaper, easier and the best option to sell your products online. With dynamic website you can take your orders and updates your products in very convenient ways.
	                    </p>
	                    <div class="call-to-action-button">
	                        <a class="big-link-3" href="#">E- commerce site</a>
	                    </div>
	                </div>
	            </div>
	        </div>
        </div>

    <div class="services-half-width-container">
        	<div class="container">
	            <div class="row">
	                <div class="col-sm-6 services-half-width-text wow fadeInLeft box2">
	                    <h3 style="color:#EE2326; text-transform:uppercase;">Content Management System (CMS)</h3>
	                    <p>
	               If your company has lots of information such as news, events, happenings, innovation or products that you want to share with the world. Then dynamic website is the best way to update your website regularly without paying much.
	                    </p>
                       
	                </div>
	                <div class="col-sm-6 services-half-width-text wow fadeInUp box1">
	                     <h3 style="color:#EE2326; text-transform:uppercase;">Members database</h3>
	                    <p>
	                  Dynamic website allows people to manage information through out the websites by using your administration interface. The dynamic website also helps users in easy login to sites.
	                    </p>
                        
	                </div>
	            </div>
                <br>
                <div id="thanks"></div>
                    <style>textarea.form-control { height: 150px; }</style>
 <button class="btn-danger button_style" data-toggle="modal" data-target="#myModal" ata-dismiss="modal" style="margin: 0 0 2%;padding: 1%;">REQUEST DEMO</button>
<div class="modal" id="myModal" style="margin-top: 150px;">
<div class="modal-dialog">
<div class="modal-content">
 <div class="modal-header" style="background-color:#0059AB;color:white;">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
&times;</button>
<h3 class="modal-title" style="color:#fff;">REQUEST DEMO</h3>

</div>
<div class="modal-body">
<div id="thanks"></div>
<form name="contactform" id="contactform" class="contactform" method="post" action="form.php">
<div class="form-group">
<label for="contact-name">Name</label>
<input type="text" name="name" placeholder="Enter your name..." class="form-control"  id="contact-name" pattern="[a-zA-Z][a-zA-Z0-9\s]*"  required>
</div>
<div class="form-group">
<label for="contact-email">Email</label>
<input type="email" name="email" placeholder="Enter your email..." class="form-control"  id="contact-email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$"   required>
</div>
<div class="form-group">
<label for="contact-subject">Subject</label>
<input type="text" name="subject" placeholder="Your subject..." class="form-control"  id="contact-subject" pattern="[a-zA-Z][a-zA-Z0-9\s]*" required>
</div>

<div class="form-group">
<label for="contact-message">Message</label>
<div class="col-sm4">
<textarea name="comment" placeholder="Your message..." class="form-control"  id="contact-message" pattern="[a-zA-Z][a-zA-Z0-9\s]*"  required></textarea></div>
</div>

<div class="modal-footer">
<input type="submit"  value="Submit" class="btn btn-info" id="formsubmit" name="submit">
</form>
</div>
</div>

</div>
</div>
</div>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>
        <!-- Call To Action -->
        
     <script>
 
//twitter bootstrap script
 $("#contactform").submit(function(ev){
    ev.preventDefault();
   
    $.ajax({
 type: "POST",
 url: "process_services.php",
 data: $('#contactform').serialize(),
 cache: false,
         success: function(msg){
             $('#thanks').html(msg);
         	 
         $("#myModal").fadeOut( "slow" );
         setTimeout('$("#myModal").hide()',1500);
         setTimeout('$(".modal-backdrop").hide()',1500);
        
         },
 error: function(){
 alert("failure");
 }
       });
 });

</script>  	        </div>
        </div>
<br class="spacer">





<?php include 'footer.php';?>