<?php include 'header.php';  ?>
<div class="inner-banner"><img src="images/digitalmarketing.jpg"></div>

<style>.portal_development h3, h4{ color:#0059ab;font-weight:bold; }.portal_development li{ list-style:disc; }.no-padding{ padding:0 !important; }.portal_demo { padding:15px 15px 15px 0; } 
#line { border-bottom: 1px solid #fff;margin-top: 10px;width: 100%; } .sidebar { background: #0059ab;color:#fff;float: left;padding: 10px;width: 28%; } .sidebar li a{ color:#fff; }
.sidebar li { list-style:none;margin-top: 10px; } .sidebar ul { padding-left:15px; }</style>
<div class="services-full-width-container">
        	<div class="container portal_development">
             <div class="col-sm-12">
              <div class="col-sm-8">
              <h3>SEO Services Company India</h3>
              <p>Search Engine optimization is an art which one has mastered yet but with years of experience it does in our work. We at Dimension I, follow ethical practices in all of SEO Services to gain organic rankings on Google, Yahoo and MSN. SEO services in India, SEO services India team of PHP programmers has proven experience in the field of high end web programming and web site development and can provide bug free, affordable and cost-effective web design solutions including complex database integrated website development,e-commerce portals,intranet web development and website maintenance.</p>                  
             
              
              <h3>SEO Services</h3>
         <!--     <div class="col-sm-12 no-padding">
              <div class="col-sm-6 portal_demo">
              <img src="images/excelanto_cloud_erp_companies_in_india_seo.jpg">
             </div>
             <div class="col-sm-6 portal_demo">
             <img src="images/excelanto_cloud_erp_company_in_chennai_seo11.jpg">
             </div>
             </div>
             
             <div class="col-sm-12 no-padding">
             <div class="col-sm-6 portal_demo">
             <img src="images/excelanto_chennai_seo_image_4.jpg">
             </div>
             <div class="col-sm-6 portal_demo">
             <img src="images/excelanto_chennai_seo_image_3.jpg">
             </div>
             </div>
             
             <div class="col-sm-12 no-padding">
             <div class="col-sm-6 portal_demo">
             <img src="images/excelanto_cloud_erp_in_chennai_seo.jpg">
             </div>
             <div class="col-sm-6 portal_demo">
             <img src="images/excelanto_cloud_erp_in_india.jpg">
             </div>
             </div>
             
             <div class="col-sm-12 no-padding">
             <div class="col-sm-6 portal_demo">
             <img src="images/excelanto_cloud_erp_in_india_seo.jpg">
             </div>
             <div class="col-sm-6 portal_demo">
             <img src="images/excelanto_cloud_erp_software_india_seo6.jpg">
             </div>
             </div>
             
              <div class="col-sm-12 no-padding">
             <div class="col-sm-6 portal_demo">
             <img src="images/excelanto_cloud_erp_software_seo5.jpg">
             </div>
             <div class="col-sm-6 portal_demo">
             <img src="images/excelanto_cms_software_chennai_seo8.jpg">
             </div>
             </div>
             
             <div class="col-sm-12 no-padding">
             <div class="col-sm-6 portal_demo">
             <img src="images/excelanto_construction_management_system_in_chennai_seo7.jpg">
             </div>
             <div class="col-sm-6 portal_demo">
             <img src="images/excelanto_erp_in_chennai_seo1.jpg">
             </div>
             </div>
             
             <div class="col-sm-12 no-padding">
             <div class="col-sm-6 portal_demo">
             <img src="images/excelanto_erp_in_india_seo10.jpg">
             </div>
             <div class="col-sm-6 portal_demo">
             <img src="images/excelanto_inventory_management_in_chennai_seo9.jpg">
             </div>
             </div>-->
             
             <br>
             <p>SEO Company Chennai - SEO Company India - Internet Marketing Company Chennai - <strong>Internet Marketing Company India - SEO Services Company Chennai - SEO Services Company India - SEO Service Providers Chennai - SEO Service Providers India</strong></p>
              <div id="thanks"></div>
                    <style>textarea.form-control { height: 150px; }</style>
 <button class="btn-danger button_style" data-toggle="modal" data-target="#myModal" ata-dismiss="modal" style="margin: 0 0 2%;padding: 1%;">REQUEST DEMO</button>
<div class="modal" id="myModal" style="margin-top: 150px;">
<div class="modal-dialog">
<div class="modal-content">
 <div class="modal-header" style="background-color:#0059AB;color:white;">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
&times;</button>
<h3 class="modal-title" style="color:#fff;">REQUEST DEMO</h3>

</div>
<div class="modal-body">
<div id="thanks"></div>
<form name="contactform" id="contactform" class="contactform" method="post" action="form.php">
<div class="form-group">
<label for="contact-name">Name</label>
<input type="text" name="name" placeholder="Enter your name..." class="form-control"  id="contact-name" pattern="[a-zA-Z][a-zA-Z0-9\s]*"  required>
</div>
<div class="form-group">
<label for="contact-email">Email</label>
<input type="email" name="email" placeholder="Enter your email..." class="form-control"  id="contact-email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$"   required>
</div>
<div class="form-group">
<label for="contact-subject">Subject</label>
<input type="text" name="subject" placeholder="Your subject..." class="form-control"  id="contact-subject" pattern="[a-zA-Z][a-zA-Z0-9\s]*" required>
</div>

<div class="form-group">
<label for="contact-message">Message</label>
<div class="col-sm4">
<textarea name="comment" placeholder="Your message..." class="form-control"  id="contact-message" pattern="[a-zA-Z][a-zA-Z0-9\s]*"  required></textarea></div>
</div>

<div class="modal-footer">
<input type="submit"  value="Submit" class="btn btn-info" id="formsubmit" name="submit">
</form>
</div>
</div>

</div>
</div>
</div>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>
        <!-- Call To Action -->
        
     <script>
 
//twitter bootstrap script
 $("#contactform").submit(function(ev){
    ev.preventDefault();
   
    $.ajax({
 type: "POST",
 url: "process_product.php",
 data: $('#contactform').serialize(),
 cache: false,
         success: function(msg){
             $('#thanks').html(msg);
         	 
         $("#myModal").fadeOut( "slow" );
         setTimeout('$("#myModal").hide()',1500);
         setTimeout('$(".modal-backdrop").hide()',1500);
        
         },
 error: function(){
 alert("failure");
 }
       });
 });

</script>               </div>
             
              <div class="col-sm-4 sidebar">              
				<h2 style="color:#fff;" title="top erp company in india" class="visible visible-first">Services</h2>
				<div id="line"></div>
				<ul>
					<li class="firstItem"><a title="seo-company-chennai.php" href="seo-services.php">SEO Services</a></li>
                    <li><a title="CMS Web Design Services company in chennai" href="web-design-services-company-chennai.php">Web Design Services</a></li>
                    <li><a title="Drupal CMS company in chennai" href="drupal-content-management-system-chennai.php">Drupal CMS</a></li>
					<li class="lastItem"><a title="Wordpress CMS company in chennai" href="wordpress-ERP-company-chennai.php">Wordpress CMS</a></li>
				</ul>			
             </div>
             
             </div>
            
	            
	        </div>
            </div>
        
        <!-- b2b-portal-development ends-->
       
      

        <!-- Call To Action -->
       


<?php include 'footer.php'; ?>