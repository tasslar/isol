<title>Inysol innovative Technology solutions - Technologies</title>
<?php include 'header.php'; ?>
<div class="inner-banner"><img src="images/Technologies.jpg" class="img-responsive"></div>
  
        <div class="services-full-width-container">
        	<div class="container">
	            <div class="row">
	                <div class="col-sm-12 services-full-width-text wow fadeInLeft">
	                  <br/>
                        <div class="col-sm-12" style="margin:15px 0;">
	                    <!--<div class="col-sm-3 logos">
						<img src="images/trendtwo.png" title="trendtwo" alt="Trendtwo">
                        </div>-->
                         <div class="col-sm-3 logos">
                        <img src="images/Tech-img-1.jpg"   class="img-responsive">
                        </div>
                         <div class="col-sm-3 logos">
                        <img src="images/Tech-img-2.jpg"   class="img-responsive">
                        </div>
                         <div class="col-sm-3 logos">
                        <img src="images/Tech-img-3.jpg"   class="img-responsive">
                        </div>
                        <!--<div class="col-sm-3 logos">
                        <span title="Viapaise"> Viapaise.com</span>
                        </div>-->
                         <div class="col-sm-3 logos">                        
                        <img src="images/Tech-img-4.jpg"   class="img-responsive">
                        </div>
                         <div class="col-sm-3 logos">
                        <img src="images/Tech-img-5.jpg"   class="img-responsive">
                        </div>
                        <!--<div class="col-sm-3 logos">
                        <span title="letsdaru">Letsdaru.com</span>
                        </div>-->
                       
                        <!--<div class="col-sm-3 logos">
                        <span title="shlokaschool">Shlokaschool.com</span>
                        </div>-->
                        
                        <div class="col-sm-3 logos">
						<img src="images/Tech-img-6.jpg"   class="img-responsive">
                        </div>
                        
                         <!--<div class="col-sm-3 logos">
                        <span title="shikafancydress">Shikafancydress.com</span>
                        </div>-->
                        
                         <!--<div class="col-sm-3 logos">
                        <span title="caterpino">Caterpino.com</span>
                        </div>-->
                        <div class="col-sm-3 logos">
						<img src="images/Tech-img-7.jpg"   class="img-responsive">
                        </div>
                        
                         <!--<div class="col-sm-3 logos">
                        <span title="papillode">Papillode.com</span>
                        </div>
                         <div class="col-sm-3 logos">
                        <span title="hisplus>Hisplus.net</span>
                        </div>
                         <div class="col-sm-3 logos">
                        <span title="threedesignstudio">Threedesignstudio.com</span>
                        </div>
                         <div class="col-sm-3 logos">
                        <span title="Pratima Björkdahl">Pratima Björkdahl.com</span>
                        </div>-->
                        
                       <div class="col-sm-3 logos">
						<img src="images/Tech-img-8.jpg"   class="img-responsive">
                        </div>
                        <!--<div class="col-sm-3 logos">
                        <span title="shopatnandyal>Shopatnandyal.com</span>
                        </div>
                        <div class="col-sm-3 logos">
                        <span title="pngwebsolutions">Pngwebsolutions.com</span>
                        </div>
                        
                        <div class="col-sm-3 logos">
                        <span title="tasstraining">Tasstraining.com</span>
                        </div>
                        <div class="col-sm-3 logos">
                        <span title="tasspages">Tasspages.com</span>
                        </div>
                        <div class="col-sm-3 logos">
                        <span title="tassads">Tassads.com</span>
                        </div>
                        <div class="col-sm-3 logos">
                        <span title="tasslistings">Tasslistings.com</span>
                        </div>
                        <div class="col-sm-3 logos">
                        <span title="tasstraders">Tasstraders.com</span>
                        </div>
                        <div class="col-sm-3 logos">
                        <span title="Vkkamakka">Vkkamakka.com</span>
                        </div>-->
                        <div class="col-sm-3 logos">
						<img src="images/Tech-img-9.jpg"   class="img-responsive">
                        </div>
                        
                        <div class="col-sm-3 logos">
						<img src="images/Tech-img-10.jpg"   class="img-responsive">
                        </div>
                        <div class="col-sm-3 logos">
						<img src="images/Tech-img-11.jpg"   class="img-responsive">
                        </div>
                         <div class="col-sm-3 logos">
						<img src="images/Tech-img-12.jpg"   class="img-responsive">
                        </div>
                        <div class="col-sm-3 logos">
						<img src="images/Tech-img-13.jpg"   class="img-responsive">
                        </div>
                        <div class="col-sm-3 logos">
						<img src="images/Tech-img-14.jpg"   class="img-responsive">
                        </div>
                         <div class="col-sm-3 logos">
						<img src="images/Tech-img-15.jpg"   class="img-responsive">
                        </div> 
                        <div class="col-sm-3 logos">
						<img src="images/Tech-img-16.jpg"   class="img-responsive">
                        </div>
                        
                        <div class="col-sm-3 logos">
						<img src="images/Tech-img-17.jpg"   class="img-responsive">
                        </div>
                         <div class="col-sm-3 logos">
						<img src="images/Tech-img-18.jpg"   class="img-responsive">
                        </div>
                         <div class="col-sm-3 logos">
						<img src="images/Tech-img-19.jpg"   class="img-responsive">
                        </div>
                        <div class="col-sm-3 logos">
						<img src="images/Tech-img-20.jpg"   class="img-responsive">
                        </div>  
                        <div class="col-sm-3 logos">
						<img src="images/Tech-img-21.jpg"   class="img-responsive">
                        </div>                
                         <div class="col-sm-3 logos">
						<img src="images/Tech-img-22.jpg"   class="img-responsive">
                        </div>
                          <div class="col-sm-3 logos">
						<img src="images/Tech-img-23.jpg"   class="img-responsive">
                        </div>
                        
                         <div class="col-sm-3 logos">
						<img src="images/Tech-img-24.jpg"   class="img-responsive">
                        </div>
                        <div class="col-sm-3 logos">
						<img src="images/Tech-img-25.jpg"   class="img-responsive">
                        </div>
                        <div class="col-sm-3 logos">
						<img src="images/Tech-img-26.jpg"   class="img-responsive">
                        </div>
                     </div>
  
                        
	                </div>
	            </div>
	        </div>
        </div>

        <!-- Services -->
       
      

        <!-- Call To Action -->
       


<?php include 'footer.php'; ?>