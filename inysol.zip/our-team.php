<title>Inysol innovative Technology solutions - Our Team</title>
<?php include 'header.php'; ?>
<div class="inner-banner"><img src="images/our-team.jpg" class="img-responsive" alt="Payment Gateway Integration, API Integration"></div>



         	<div class="container">
	            <div class="row">
	                <div class="col-sm-12 services-full-width-text wow fadeInLeft">
	                    <h3 >Our Team</h3>
                        </div></div></div>
                        
                        <div id="white-bg">
                        <div class="container">
                            <div class="row">
                                <div class="col-sm-4 services-full-width-text wow fadeInLeft">
                                    <div class="white-bg">
                                        <div align="center"><img class="img-responsive" src="images/profile_image_male.jpg" title="Mr.Sant"></div>
                                         <h4 align="center">Mr.Surya devan</h4>
                                  <span align="center">Vice President - Consultant, Sales and Marketing</span>
                                  <p style="text-align:center">Mr. Surya devan is a Certified Software Tester (VP) and holds a Master’s degree in business Administration from the University of Essex, UK. A true professional in the software sales & digital Marketing field, he has extensive experience of 25 years in the software sales & digital Marketing, working in Inysol Innovative Solutions since 2009 and thereby acquiring an in-depth understanding of Sales & Marketing. He is well experienced in software Testing, evaluating and analyzing strategies and business planning, for different Business Domain.</p>
                                    </div>
                                </div>
                                
                                 
                                <div class="col-sm-4 services-full-width-text wow fadeInLeft">
                                    <div class="white-bg">
                                        <div align="center"><img class="img-responsive" src="images/profile_image_male.jpg" title="Mr.Sant"></div>
                                         <h4 align="center">Mr. Nani Prasad</h4>
                                  <span align="center">Head of Technology</span>
                                  <p> Mr.Nani prasad is a Certified Technical Architect (Head of Technology) and holds a MASTERS IN INTERNET TECHNOLOGIES from the University Of Mumbai, India. A true professional in the Software Technologies field, he has extensive experience of 15 years in the Software Development working in Inysol Innovative Solutions since 2009 and thereby acquiring an in-depth understanding of all Latest Technologies. He is well experienced in Software Development Life cycle, evaluating and analyzing strategies and Preparing High Level documents, business planning, for different Business Domain around the world. </p>
                                    </div>
                                </div>
                                
                                
                              
                                <div class="col-sm-4 services-full-width-text wow fadeInLeft">
                                    <div class="white-bg">
                                        <div align="center"><img class="img-responsive" src="images/profile_image_male.jpg" title="Mr.Sant"></div>
                                         <h4 align="center">Ms.Shmi</h4>
                                  <span align="center">Operation Manager – Sales</span>
                                   <p> Ms. Shmi is a Certified HR Specialties and holds a Master degree in Business Administration

from Madras university , Chennai. A Professional in HR and Manager in Sales for past 10 years in

Inysol Innovative Solutions since 2009. She is well experienced in HR and Sales Operations . </p>
                                    </div>
                                </div>
                            
                            </div><!--row -->
                             </div></div>
                        
	                  <!--  <p>
	                    We at Inysol Innovative Solutions are proud to have a manpower that leads the organization and its clients towards success. IT Solution is a complex process and knowledgeable IT wizards can only resolve it. The company is proud to have the most talented and creative professionals working in its team.
We have a strong foundation of intellectual capital and result-orientation. The team is a strategic mix of professionals from technology, consulting, business management and client servicing domains.

It includes web designer, web developer, software developer, content writer, graphic designer / visualizer, management professional And Expert Search Engine Optimzer.

Our dedicated and skilled team of creative professionals has gained a reputation for providing the best services as per industry standards and concentrates on the key areas of web design, web development and internet marketing.
	                	</p>-->
                        
  

<?php include 'footer-inner.php'; ?>