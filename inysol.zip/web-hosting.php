<?php include 'header.php'; ?>
<div class="inner-banner"><img src="images/hosting.jpg"></div>

        <div class="services-full-width-container">
        	<div class="container">
	            <div class="row">
	                <div class="col-sm-12 services-full-width-text wow fadeInLeft">
	                    <h3 style="color:#EE2326; text-transform:uppercase;">Web Hosting</h3>
	                    <p>
	                    	Inysol Innovative Solutions providing Linux and Windows web hosting service to ecommerce website, dynamic website, static website, Our hosting support both PHP 4.x and PHP 5 hosting, MySQL, ASP, ASP.NET. We also provide domain name registration, affordable Linux hosting as well as windows hosting also we are providing VPS server, Dedicated Window as well as Linux servers.

We provide Excellent and Level 5 quick support to our all the valuable customers via live chat, via phone, via trouble ticket also we are providing on site support to our client.

Currently we are maintaining more than 100 domains in our server of different countries like of India, UK, Dubai, and Japan. We provide Cpanel interface for Linux Shared Web hosting and HELM for Windows Web hosting as control panel.

If you have simple static HTML website or dynamic website built in php, mysql, asp or asp.net we have can provide you best hosting for it with Level 5 support.
	                	</p>
                          <h3 style="color:#EE2326; text-transform:uppercase;">Linux Server Shared Hosting</h3>
	                    <p>
	                    	 Inysol Innovative Solutions is offering very affordable Linux Web Hosting solution,

Linux Shared Hosting is supported for PHP, MySQL, Perl, PHPMyAdmin, Servlet/JSP Tomcat, and Ruby on Rails, Site Builder, Unlimited Add-on, Sub domains, and Parked domains.

Linux Shared Hosting is a wonderful part of Cpanel control. It integrates with Cpanel and gives the ability to automatically install a variety of open source scripts with our low cost web hosting packages, in Linux shared hosting you can restore files via your CPanel control panel and also you can able to restore your lost data yourself within minutes instead of having to raise a support ticket and thereby save your precious time!
	                	</p>
	                </div>
	            </div>
	        </div>
        </div>

       
        <!-- Services Half Width Text -->
        <div class="services-half-width-container">
        	<div class="container">
	            <div class="row">
	                <div class="col-sm-6 services-half-width-text wow fadeInLeft box2">
	                    <h3 style="color:#EE2326; text-transform:uppercase;">Linux Reseller Web Hosting</h3>
	                    <p>
	         Inysol Innovative Solutions is offering very affordable Linux Reseller Web Hosting Solution
	                    </p>
                       
	                </div>
	                <div class="col-sm-6 services-half-width-text wow fadeInUp box4">
	                     <h3 style="color:#EE2326; text-transform:uppercase;">Windows Server Shared Hosting</h3>
	                    <p>
	                    	Inysol Innovative Solutions is offering very affordable Window Server Shared Web Hosting Solution,
	                    </p>
	                </div>
	            </div>
	        </div>
        </div>
         <div class="services-half-width-container">
        	<div class="container">
	            <div class="row">
	                <div class="col-sm-6 services-half-width-text wow fadeInLeft box">
	                    <h3 style="color:#EE2326; text-transform:uppercase;">VPS Server</h3>
	                    <p>
Inysol Innovative Solutions is offering very reasonable VPS Server , Virtual Private Server technology presents multiple isolated server environments on a single physical server.

VPS hosting allow many customers to contribute the expenditure of hardware and network connections without sacrificing privacy, performance or preference. VPS hosting provides the flexibility to add and change software and install your own software along with the features and functionality of a dedicated server without the cost of building and maintaining one. In nearly every perspective you can see a VPS as if it's a dedicated server.

If you need to host unlimited domains account, have complete control of your server and run your own applications, then you will get advantage from having a VPS web hosting account. Including that a VPS provides the ability to manage your dedicated server directly through SSH.	                    </p>
                       
	                </div>
	                <div class="col-sm-6 services-half-width-text wow fadeInUp box1">
	                     <h3 style="color:#EE2326; text-transform:uppercase;">Domain Registration</h3>
	                    <p>
	                    	We at Inysol Innovative Solutions providing all types extension of domain registration.

We are connected with the major domain registrar in India. This enables us to offer domain name registration services at a very affordable cost. We offer registration services with many top registrars around the world.

This enables us easy registration of country level domains and other quality domains and also renewal and transfer of domain names. 

At present Inysol Innovative Solutions providing following domain registrations.
	                    </p>
	                </div>
	            </div>
                <br>
                <div id="thanks"></div>
                    <style>textarea.form-control { height: 150px; }</style>
 <button class="btn-danger button_style" data-toggle="modal" data-target="#myModal" ata-dismiss="modal" style="margin: 0 0 2%;padding: 1%;">REQUEST DEMO</button>
<div class="modal" id="myModal" style="margin-top: 150px;">
<div class="modal-dialog">
<div class="modal-content">
 <div class="modal-header" style="background-color:#0059AB;color:white;">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
&times;</button>
<h3 class="modal-title" style="color:#fff;">REQUEST DEMO</h3>

</div>
<div class="modal-body">
<div id="thanks"></div>
<form name="contactform" id="contactform" class="contactform" method="post" action="form.php">
<div class="form-group">
<label for="contact-name">Name</label>
<input type="text" name="name" placeholder="Enter your name..." class="form-control"  id="contact-name" pattern="[a-zA-Z][a-zA-Z0-9\s]*"  required>
</div>
<div class="form-group">
<label for="contact-email">Email</label>
<input type="email" name="email" placeholder="Enter your email..." class="form-control"  id="contact-email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$"   required>
</div>
<div class="form-group">
<label for="contact-subject">Subject</label>
<input type="text" name="subject" placeholder="Your subject..." class="form-control"  id="contact-subject" pattern="[a-zA-Z][a-zA-Z0-9\s]*" required>
</div>

<div class="form-group">
<label for="contact-message">Message</label>
<div class="col-sm4">
<textarea name="comment" placeholder="Your message..." class="form-control"  id="contact-message" pattern="[a-zA-Z][a-zA-Z0-9\s]*"  required></textarea></div>
</div>

<div class="modal-footer">
<input type="submit"  value="Submit" class="btn btn-info" id="formsubmit" name="submit">
</form>
</div>
</div>

</div>
</div>
</div>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>
        <!-- Call To Action -->
        
     <script>
 
//twitter bootstrap script
 $("#contactform").submit(function(ev){
    ev.preventDefault();
   
    $.ajax({
 type: "POST",
 url: "process_services.php",
 data: $('#contactform').serialize(),
 cache: false,
         success: function(msg){
             $('#thanks').html(msg);
         	 
         $("#myModal").fadeOut( "slow" );
         setTimeout('$("#myModal").hide()',1500);
         setTimeout('$(".modal-backdrop").hide()',1500);
        
         },
 error: function(){
 alert("failure");
 }
       });
 });

</script>  	        </div>
        </div>

        <!-- Call To Action -->
       

<?php include 'footer.php'; ?>